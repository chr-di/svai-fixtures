/* global React */
const { useState: useStateB, useEffect: useEffectB } = React;

/* ──────────────────────────────────────────────
   Schedule
   ────────────────────────────────────────────── */
const SCHEDULE = {
  Mon: [
    ["07:00", "Reformer · Foundational", "Marice S.", 1, false],
    ["09:30", "Mat & Props", "Lina H.", 1, false],
    ["12:15", "Reformer · Express", "Marice S.", 2, true],
    ["18:00", "Reformer · Intermediate", "Tomás R.", 2, false],
    ["19:30", "Power Mat", "Lina H.", 2, false],
  ],
  Tue: [
    ["06:30", "Reformer · Foundational", "Tomás R.", 1, false],
    ["08:00", "Pre-natal", "Marice S.", 1, false],
    ["12:30", "Reformer · Intermediate", "Lina H.", 2, false],
    ["17:00", "Mobility & Recovery", "Marice S.", 1, false],
    ["18:30", "Reformer · Advanced", "Tomás R.", 3, true],
  ],
  Wed: [
    ["07:00", "Reformer · Foundational", "Marice S.", 1, false],
    ["10:00", "Mat & Props", "Lina H.", 1, false],
    ["12:15", "Reformer · Express", "Tomás R.", 2, false],
    ["18:00", "Reformer · Advanced", "Marice S.", 3, false],
    ["19:30", "Pre-natal · T3", "Lina H.", 1, false],
  ],
  Thu: [
    ["06:30", "Slow Mat", "Lina H.", 1, false],
    ["09:00", "Reformer · Intermediate", "Marice S.", 2, false],
    ["12:00", "Pre-natal", "Lina H.", 1, false],
    ["17:30", "Reformer · Foundational", "Tomás R.", 1, false],
    ["19:00", "Reformer · Intermediate", "Marice S.", 2, true],
  ],
  Fri: [
    ["07:00", "Reformer · Foundational", "Tomás R.", 1, false],
    ["09:30", "Power Mat", "Lina H.", 2, false],
    ["12:15", "Reformer · Express", "Marice S.", 2, false],
    ["17:00", "Reformer · Intermediate", "Marice S.", 2, false],
    ["18:30", "Mobility & Recovery", "Lina H.", 1, false],
  ],
  Sat: [
    ["08:00", "Reformer · Advanced", "Marice S.", 3, false],
    ["09:30", "Mat & Props", "Lina H.", 1, false],
    ["11:00", "Post-natal Return", "Marice S.", 1, false],
    ["12:30", "Reformer · Intermediate", "Tomás R.", 2, false],
  ],
  Sun: [
    ["09:00", "Mobility & Recovery", "Lina H.", 1, false],
    ["10:30", "Reformer · Foundational", "Marice S.", 1, false],
    ["12:00", "Slow Mat", "Lina H.", 1, false],
  ],
};

const DAY_NUMS = { Mon: 4, Tue: 5, Wed: 6, Thu: 7, Fri: 8, Sat: 9, Sun: 10 };

function Schedule({ onBook }) {
  const [day, setDay] = useStateB("Mon");
  const rows = SCHEDULE[day];
  return (
    <section className="schedule" id="schedule" data-screen-label="06 Schedule">
      <div className="wrap">
        <div className="head">
          <span className="eyebrow">This week</span>
          <h2>Find your spot.</h2>
        </div>
        <div className="day-tabs">
          {Object.keys(SCHEDULE).map((d) => (
            <button key={d} className={day === d ? "active" : ""} onClick={() => setDay(d)}>
              <span>{d}</span>
              <span className="num">{DAY_NUMS[d]}</span>
            </button>
          ))}
        </div>
        <div className="schedule-list">
          {rows.map((r, i) => {
            const [time, name, trainer, level, full] = r;
            const [base, ...rest] = name.split(" · ");
            return (
              <div className={"sched-row" + (full ? " full" : "")} key={i}>
                <div className="time">{time}</div>
                <div className="name">{base}{rest.length ? <small>{rest.join(" · ")}</small> : null}</div>
                <div className="trainer">{trainer}</div>
                <div><span className={"level l" + level}>Level {level}</span></div>
                <button className="book" onClick={onBook} disabled={full}>
                  {full ? "Waitlist" : "Book →"}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Pricing
   ────────────────────────────────────────────── */
const PLANS = [
  {
    name: "Drop-in",
    price: "32",
    unit: "CHF / session",
    desc: "Walk in, work out. No commitment.",
    features: ["Single class booking", "Reformer or Mat", "Valid for 30 days", "Cancel up to 12h before"],
    cta: "Book a session",
    featured: false,
  },
  {
    name: "Monthly",
    price: "289",
    unit: "CHF / month",
    desc: "8 group sessions, programmed weekly.",
    features: ["8 classes / month", "All group formats", "Priority booking 7 days out", "Studio amenities included"],
    cta: "Start membership",
    featured: true,
    badge: "Most chosen",
  },
  {
    name: "Private",
    price: "120",
    unit: "CHF / session",
    desc: "1:1 with a senior trainer.",
    features: ["60-min private session", "Custom programming", "Full equipment access", "Bring one guest, twice"],
    cta: "Request consultation",
    featured: false,
  },
];

function Pricing({ onBook }) {
  return (
    <section className="pricing" id="pricing" data-screen-label="07 Pricing">
      <div className="wrap">
        <div className="head">
          <span className="eyebrow">Memberships</span>
          <h2 className="serif">Honest pricing, <em>no contracts,</em> no nonsense.</h2>
        </div>
        <div className="pricing-grid">
          {PLANS.map((p) => (
            <div className={"plan" + (p.featured ? " featured" : "")} key={p.name}>
              {p.badge && <span className="badge">{p.badge}</span>}
              <div className="plan-name">{p.name}</div>
              <div className="plan-price">{p.price}<small>{p.unit}</small></div>
              <div className="plan-desc">{p.desc}</div>
              <ul>
                {p.features.map((f) => <li key={f}>{f}</li>)}
              </ul>
              <button className="pill" onClick={onBook}>{p.cta} →</button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Trainer
   ────────────────────────────────────────────── */
function Trainer() {
  return (
    <section className="trainer" id="trainer" data-screen-label="08 Trainer">
      <div className="wrap trainer-grid">
        <div className="visual">
          portrait · trainer
          <div className="stamp">
            <span>Marice S.</span>
            <span>est. 2018</span>
          </div>
        </div>
        <div>
          <h2 className="serif">
            <small>Lead trainer · Founder</small>
            Marice Solimano
          </h2>
          <p>Eight years on a reformer, four certifications, one studio. Marice opened the Zentrum after years of teaching in studios where she felt clients deserved more attention than the timetable allowed.</p>
          <p>Her sessions blend classical Pilates with rehabilitative work — born from her own recovery from a long-distance running injury that no amount of physiotherapy alone could fix.</p>
          <dl className="creds">
            <div><dt>STOTT</dt><dd>Comprehensive certification</dd></div>
            <div><dt>BASI</dt><dd>Pre & post-natal</dd></div>
            <div><dt>8 yrs</dt><dd>Teaching experience</dd></div>
            <div><dt>2,400+</dt><dd>Sessions delivered</dd></div>
          </dl>
          <div style={{ display: "flex", gap: 12 }}>
            <button className="pill">Book with Marice</button>
            <button className="pill outline symmetric">Meet the team</button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Testimonials
   ────────────────────────────────────────────── */
const TESTI = [
  { name: "Elena R.", who: "Member, 2 yrs",  init: "E", text: "I came in with a herniated disc and a lot of skepticism. Two years on, my back is the strongest it has ever been." },
  { name: "Davide F.",  who: "Member, 1 yr",   init: "D", text: "The smallest details are what make it work. Marice will spot a foot rotation from across the room and quietly fix it mid-rep." },
  { name: "Carla M.",  who: "Pre-natal client", init: "C", text: "I trained right up to week 38. The programming adapted as I changed — I felt held, not coddled." },
  { name: "Tom W.",    who: "Member, 6 mo",  init: "T", text: "Half the price of the chain studio I left and three times the attention. The math is not subtle." },
  { name: "Aïsha B.",  who: "Private client",   init: "A", text: "After a knee surgery I was scared to move. Six weeks later I was running again. Worth every centime." },
];

function Testimonials() {
  return (
    <section className="testimonials" id="testimonials" data-screen-label="09 Testimonials">
      <div className="head wrap">
        <span className="eyebrow">From the studio</span>
        <h2 className="serif">Words from <em>the people</em> on the reformers.</h2>
      </div>
      <div className="testimonials-rail">
        {TESTI.map((t, i) => (
          <div className="testimonial" key={i}>
            <div className="stars">★ ★ ★ ★ ★</div>
            <blockquote>"{t.text}"</blockquote>
            <div className="who">
              <div className="avatar">{t.init}</div>
              <div className="meta">
                {t.name}
                <small>{t.who}</small>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   FAQ
   ────────────────────────────────────────────── */
const FAQS = [
  ["I've never done Pilates before. Where do I start?", "Begin with a Reformer Foundational class or a private intro session. We'll spend the first 10 minutes walking through the equipment, breath, and neutral spine before you start moving."],
  ["What should I wear and bring?", "Form-fitting activewear (loose tops can get caught in springs), grip socks, and a water bottle. Towels and grip socks are also available at reception."],
  ["How far in advance can I book?", "Members can book seven days ahead. Drop-in clients can book three days ahead. The booking window resets at midnight."],
  ["What's your cancellation policy?", "Cancel up to twelve hours before class with no penalty. Late cancellations forfeit the session credit."],
  ["Do you offer pre-natal classes?", "Yes — we run a small pre-natal group of four reformers, programmed by trimester. All trainers leading these classes are pre & post-natal certified."],
  ["Is parking available?", "Two-hour street parking is available on Bahnhofstrasse. The Hauptbahnhof is a six-minute walk."],
];

function FAQ() {
  const [open, setOpen] = useStateB(0);
  return (
    <section className="faq" id="faq" data-screen-label="10 FAQ">
      <div className="wrap grid">
        <h2 className="serif"><em>Practical</em> answers to the <em>practical</em> questions.</h2>
        <div className="faq-list">
          {FAQS.map(([q, a], i) => (
            <div className={"faq-item" + (open === i ? " open" : "")} key={i}>
              <button className="faq-q" onClick={() => setOpen(open === i ? -1 : i)}>
                <span>{q}</span>
                <span className="icon">+</span>
              </button>
              <div className="faq-a"><div className="inner">{a}</div></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   CTA
   ────────────────────────────────────────────── */
function CTA({ onBook }) {
  return (
    <section className="cta wrap" data-screen-label="11 CTA">
      <div className="cta-card">
        <span className="eyebrow" style={{ color: "var(--cream)", opacity: 0.85 }}>Your first class</span>
        <h2 className="serif">Step on the reformer.<br/>The rest follows.</h2>
        <p>First-time visitors get an introductory session at half-price. Bring a friend, bring a question, leave with a programme.</p>
        <div className="actions">
          <button className="pill" onClick={onBook}>Book intro session</button>
          <button className="pill outline">Visit the studio</button>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Footer
   ────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="site-footer" data-screen-label="12 Footer">
      <div className="wrap">
        <div className="foot-grid">
          <div className="foot-brand">
            <div className="logo">
              <LogoMark />
              <span style={{ fontFamily: "var(--display)", fontSize: 22, color: "var(--orange)" }}>Pilates Zentrum</span>
            </div>
            <p>Marice Solimano · Pilates Zentrum. A boutique reformer studio. Bahnhofstrasse 42, 8001 Zürich.</p>
          </div>
          <div>
            <h4>Studio</h4>
            <ul>
              <li><a href="#about">About</a></li>
              <li><a href="#classes">Classes</a></li>
              <li><a href="#trainer">Trainer</a></li>
              <li><a href="#studio">The space</a></li>
            </ul>
          </div>
          <div>
            <h4>Practise</h4>
            <ul>
              <li><a href="#schedule">Schedule</a></li>
              <li><a href="#pricing">Memberships</a></li>
              <li><a href="#faq">FAQ</a></li>
              <li><a href="#">Gift vouchers</a></li>
            </ul>
          </div>
          <div>
            <h4>Visit</h4>
            <ul>
              <li>Bahnhofstrasse 42</li>
              <li>8001 Zürich</li>
              <li>+41 44 123 45 67</li>
              <li>hello@pilateszentrum.ch</li>
            </ul>
          </div>
        </div>
        <div className="foot-bottom">
          <span>© 2026 Marice Solimano · Pilates Zentrum. All rights reserved.</span>
          <div className="socials">
            <a href="#" aria-label="Instagram">IG</a>
            <a href="#" aria-label="Facebook">FB</a>
            <a href="#" aria-label="LinkedIn">in</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ──────────────────────────────────────────────
   Booking modal
   ────────────────────────────────────────────── */
function BookingModal({ open, onClose }) {
  const [form, setForm] = useStateB({ name: "", email: "", date: "", class: "Reformer · Foundational" });
  const [err, setErr] = useStateB({});
  const [done, setDone] = useStateB(false);

  useEffectB(() => {
    if (!open) { setDone(false); setErr({}); }
    const onKey = (e) => { if (e.key === "Escape" && open) onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  const submit = (e) => {
    e.preventDefault();
    const next = {};
    if (!form.name.trim()) next.name = "Please enter your name";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = "Looks like that email isn't right";
    if (!form.date) next.date = "Pick a date";
    setErr(next);
    if (Object.keys(next).length === 0) setDone(true);
  };

  return (
    <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <button className="x" onClick={onClose} aria-label="Close">×</button>
        {done ? (
          <div className="success">
            <div className="check">✓</div>
            <h3>You're in.</h3>
            <p className="sub">A confirmation is on its way to {form.email}. We'll see you on the reformer, {form.name.split(" ")[0]}.</p>
            <button className="pill" style={{ marginTop: 12 }} onClick={onClose}>Close</button>
          </div>
        ) : (
          <form onSubmit={submit}>
            <h3>Book a session</h3>
            <p className="sub">First-time visitors — your intro session is half-price.</p>
            <label>Full name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Marice Solimano" />
            {err.name && <div className="err show">{err.name}</div>}

            <label>Email</label>
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
            {err.email && <div className="err show">{err.email}</div>}

            <label>Class</label>
            <select value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })}>
              {["Reformer · Foundational", "Reformer · Intermediate", "Reformer · Advanced", "Mat & Props", "Pre-natal", "Private 1:1"].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>

            <label>Date</label>
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            {err.date && <div className="err show">{err.date}</div>}

            <button type="submit" className="pill">Confirm booking →</button>
          </form>
        )}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────
   Reveal-on-scroll observer
   ────────────────────────────────────────────── */
function useReveal() {
  useEffectB(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

Object.assign(window, { Schedule, Pricing, Trainer, Testimonials, FAQ, CTA, Footer, BookingModal, useReveal });
