/* global React, ReactDOM */
const { useState, useEffect, useRef } = React;

/* ──────────────────────────────────────────────
   Logo (reconstructed from Figma SVG geometry)
   ────────────────────────────────────────────── */
function LogoMark({ className }) {
  return (
    <svg className={className} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path
        className="swoosh"
        d="M6 38 C 12 22, 24 22, 30 32 C 36 42, 48 42, 54 28"
        stroke="currentColor" strokeWidth="4" strokeLinecap="round" fill="none"
      />
      <circle className="ball" cx="46" cy="18" r="5" fill="currentColor" />
    </svg>
  );
}

/* ──────────────────────────────────────────────
   Header
   ────────────────────────────────────────────── */
function Header({ onContact }) {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const links = [
    ["About", "about"],
    ["Approach", "approach"],
    ["Classes", "classes"],
    ["Studio", "studio"],
    ["Schedule", "schedule"],
    ["Pricing", "pricing"],
  ];
  const go = (id) => (e) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    setOpen(false);
  };
  return (
    <header className={"site-header" + (solid ? " solid" : "")}>
      <a href="#top" className="logo" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
        <span className="logo-mark"><LogoMark /></span>
        <span className="logo-text">
          Marice Solimano
          <small>Pilates Zentrum</small>
        </span>
      </a>
      <nav className="site-nav" style={{ display: open ? "flex" : undefined }}>
        {links.map(([label, id]) => (
          <a key={id} href={"#" + id} onClick={go(id)}>{label}</a>
        ))}
      </nav>
      <button className="pill symmetric" onClick={onContact} style={{ marginLeft: 16 }}>
        Contact
      </button>
    </header>
  );
}

/* ──────────────────────────────────────────────
   Hero (matches the Figma frame)
   ────────────────────────────────────────────── */
function Hero({ onBook }) {
  return (
    <section className="hero" id="top" data-screen-label="01 Hero">
      <div className="wrap">
        <div className="tag-row">
          <button className="pill" onClick={onBook}>Pilates Zentrum</button>
        </div>
        <h1>
          <span className="row">
            <span className="word r1">Move</span>
            <span className="dot" />
            <span className="word r3">Breathe</span>
          </span>
          <span className="row">
            <span className="word r1">Restore</span>
            <span className="word r3">Together</span>
          </span>
        </h1>
        <p className="lede">
          A boutique reformer studio in the heart of the city — small classes,
          considered programming, and trainers who actually watch you move.
        </p>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Marquee
   ────────────────────────────────────────────── */
function Marquee() {
  const items = ["Reformer", "Mat", "Tower", "Cadillac", "Pre-natal", "Rehabilitative", "Private"];
  const row = (
    <>
      {items.map((t, i) => (
        <React.Fragment key={i}>
          <span>{t}</span>
          <span className="dot" />
        </React.Fragment>
      ))}
    </>
  );
  return (
    <div className="marquee">
      <div className="marquee-track">
        {row}{row}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────
   About (preserves Figma layout exactly)
   ────────────────────────────────────────────── */
function About() {
  return (
    <section className="about" id="about" data-screen-label="02 About">
      <div className="wrap">
        <button className="pill tag">About us</button>
        <h2 className="serif">
          Where every client is met with professionalism, precision and a truly human connection.
        </h2>
        <div className="about-grid">
          <div className="tile short"><div className="placeholder">studio · 1</div></div>
          <div className="tile"><div className="placeholder">reformer · 2</div></div>
          <div className="tile tall"><div className="placeholder">portrait · 3</div></div>
          <div className="tile short"><div className="placeholder">detail · 4</div></div>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Approach
   ────────────────────────────────────────────── */
function Approach() {
  const items = [
    { n: "01", t: "Assess",  d: "Every new client begins with a movement assessment. We look at how you actually move — not how you think you do." },
    { n: "02", t: "Program", d: "Sessions are designed around your goals: rehab, performance, longevity. No generic flows, no filler." },
    { n: "03", t: "Refine",  d: "Trainers stay close. Cues, corrections, and small adjustments are what make Pilates work — and why we keep classes tiny." },
  ];
  return (
    <section className="approach wrap" id="approach" data-screen-label="03 Approach">
      <div className="head">
        <h2 className="serif">A practice <em>built around you,</em> not the timetable.</h2>
        <p>Three steps shape every body that walks through our doors. Whether you're rebuilding from injury or chasing a new personal best, the framework is the same.</p>
      </div>
      <div className="pillars">
        {items.map((p) => (
          <div className="pillar" key={p.n}>
            <div className="pillar-num">{p.n}</div>
            <h3>{p.t}</h3>
            <p>{p.d}</p>
            <div className="pillar-arrow">↗</div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Classes
   ────────────────────────────────────────────── */
const CLASSES = {
  reformer: {
    name: "Reformer",
    eyebrow: "Group · 6 spots",
    headline: "Spring resistance, full-body sequencing.",
    duration: "55 min",
    capacity: "max. 6",
    level: "All levels",
    desc: "Our flagship class. Built around the reformer with progressions for every level — long, fluid sequences that lengthen, strengthen and challenge your control.",
    bullets: [
      ["Foundational", "Mon · Wed · Fri"],
      ["Intermediate", "Tue · Thu · Sat"],
      ["Advanced", "Wed · Sat"],
    ],
    visual: "reformer · group of 6",
  },
  mat: {
    name: "Mat & Props",
    eyebrow: "Group · 10 spots",
    headline: "Classical mat, modern programming.",
    duration: "50 min",
    capacity: "max. 10",
    level: "All levels",
    desc: "Pure mat work with bands, balls and small props. The cleanest way to feel where you actually live in your body — no machinery, no excuses.",
    bullets: [
      ["Slow Mat", "Mon · Thu"],
      ["Power Mat", "Tue · Fri"],
      ["Mobility & Recovery", "Sun"],
    ],
    visual: "mat class · 10 stations",
  },
  private: {
    name: "Private 1:1",
    eyebrow: "Solo · By appointment",
    headline: "Just you, the trainer, and the room.",
    duration: "60 min",
    capacity: "1:1",
    level: "Tailored",
    desc: "For clients with specific goals: post-injury rehabilitation, pregnancy, performance, or simply faster progress. Programming is rewritten between every session.",
    bullets: [
      ["Rehabilitative", "By appointment"],
      ["Performance", "By appointment"],
      ["Pre & Post-natal", "By appointment"],
    ],
    visual: "1:1 session",
  },
  prenatal: {
    name: "Pre-natal",
    eyebrow: "Group · 4 spots",
    headline: "Strength for the body that's changing.",
    duration: "50 min",
    capacity: "max. 4",
    level: "All trimesters",
    desc: "Designed by trainers certified in pre & post-natal Pilates. Classes are programmed for each trimester — pelvic stability, breath work, and gentle strength.",
    bullets: [
      ["Trimester 1 & 2", "Tue · Thu"],
      ["Trimester 3", "Wed"],
      ["Post-natal Return", "Sat"],
    ],
    visual: "pre-natal · 4 reformers",
  },
};

function Classes() {
  const [tab, setTab] = useState("reformer");
  const c = CLASSES[tab];
  return (
    <section className="classes" id="classes" data-screen-label="04 Classes">
      <div className="wrap">
        <div className="head">
          <span className="eyebrow">What we offer</span>
          <h2>Four ways to practice with us.</h2>
        </div>
        <div className="class-tabs">
          {Object.entries(CLASSES).map(([k, v]) => (
            <button key={k} className={tab === k ? "active" : ""} onClick={() => setTab(k)}>
              {v.name}
            </button>
          ))}
        </div>
        <div className="class-card">
          <div className="visual">{c.visual}</div>
          <div>
            <span className="eyebrow">{c.eyebrow}</span>
            <h3 style={{ marginTop: 8 }}>{c.headline}</h3>
            <div className="meta">
              <span>⏱ {c.duration}</span>
              <span>◯ {c.capacity}</span>
              <span>△ {c.level}</span>
            </div>
            <p className="desc">{c.desc}</p>
            <ul className="bullets">
              {c.bullets.map(([k, v]) => (
                <li key={k}><span>{k}</span><span style={{ color: "var(--ink-soft)", fontSize: 13 }}>{v}</span></li>
              ))}
            </ul>
            <div className="actions">
              <button className="pill">Book a class</button>
              <button className="pill outline symmetric">Programme details</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────
   Studio (extending the rectangle pattern from Figma)
   ────────────────────────────────────────────── */
function Studio() {
  const tiles = [
    ["t1", "studio · wide"],
    ["t2", "tower"],
    ["t3", "reformer detail"],
    ["t4", "city view"],
    ["t5", "lobby"],
    ["t6", "props"],
  ];
  return (
    <section className="studio wrap" id="studio" data-screen-label="05 Studio">
      <div className="head">
        <h2 className="serif">A studio with <em>a view,</em> and not much else in the way.</h2>
        <p>Twelve reformers, two towers, a Cadillac and floor-to-ceiling windows. We kept the floor plan deliberately spare — the body is the focus, not the decor.</p>
      </div>
      <div className="studio-grid">
        {tiles.map(([cls, label]) => (
          <div className={"tile " + cls} key={cls}>
            <div className="placeholder">{label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

Object.assign(window, { LogoMark, Header, Hero, Marquee, About, Approach, Classes, Studio });
